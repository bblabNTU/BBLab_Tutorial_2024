#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgcodecs/imgcodecs.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/video/video.hpp>
#include <opencv2/opencv.hpp>
#include <QTabWidget>
#include <QLabel>
#include <QSlider>
#include <QVBoxLayout>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}

QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void loadImage();
    void updateBinaryImage(int threshold);
    void on_thresholdSlider_valueChanged(int value);

private:
    Ui::MainWindow *ui;

    // Mat為cv儲存圖像數據的資料型態
    cv::Mat originalImage;
    cv::Mat meanGrayImage;
    cv::Mat cvGrayImage;
    cv::Mat binaryImage;
    cv::Mat filteredImage1;
    cv::Mat filteredImage2;
    cv::Mat filteredImage3;

    void displayImage(QLabel *label, const cv::Mat &image);
    void displayHistogram(QLabel *label, const cv::Mat &grayImage);
    cv::Mat computeMeanGray(const cv::Mat &image);
    cv::Mat convertToGray(const cv::Mat &image);
    cv::Mat applyThreshold(const cv::Mat &grayImage, int threshold);
    void applyFilters(const cv::Mat &image);

    int threshold;
};
#endif // MAINWINDOW_H
