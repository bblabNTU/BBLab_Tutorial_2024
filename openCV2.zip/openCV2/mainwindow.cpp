#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QImage>
#include <QPixmap>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->thresholdSlider->setVisible(false); // 先隱藏拉桿

    setWindowTitle("Image Processing Application");

    // 連接文件菜單的打開圖像操作
    connect(ui->loadAction, &QAction::triggered, this, &MainWindow::loadImage);
    // 連接閾值滑桿的值變化信號
    connect(ui->thresholdSlider, &QSlider::valueChanged, this, &MainWindow::updateBinaryImage);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 加載圖像
void MainWindow::loadImage()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open Image", "", "Image Files (*.png *.jpg *.bmp)");
    if (!fileName.isEmpty()) {
        originalImage = cv::imread(fileName.toStdString());
        displayImage(ui->originalImageLabel, originalImage);

        meanGrayImage = computeMeanGray(originalImage);
        displayImage(ui->meanGrayImageLabel, meanGrayImage);
        displayHistogram(ui->meanGrayHistogramLabel, meanGrayImage);

        cvGrayImage = convertToGray(originalImage);
        displayImage(ui->cvGrayImageLabel, cvGrayImage);
        displayHistogram(ui->cvGrayHistogramLabel, cvGrayImage);

        updateBinaryImage(ui->thresholdSlider->value());

        applyFilters(originalImage);

        // 把提示文字刪掉
        ui -> label_t1 -> setText("");
        ui -> label_t2 -> setText("");
        // 顯示圖例及拉桿
        ui -> label_p1 -> setText("原圖");
        ui -> label_p2 -> setText("用Mean灰階化");
        ui -> label_p3 -> setText("用function灰階化");
        ui -> label_p4 -> setText("二值化");
        ui -> label_h1 -> setText("Mean灰階化直方圖");
        ui -> label_h2 -> setText("function灰階化直方圖");
        ui -> label_f1 -> setText("Filter 1: Blur");
        ui -> label_f2 -> setText("Filter 2: Gaussian Blur");
        ui -> label_f3 -> setText("Filter 3: Edge Detection (Canny)");
        ui -> thresholdSlider -> setVisible(true);
    }
}

void MainWindow::on_thresholdSlider_valueChanged(int value)
{
    threshold = value;
}


// 更新二值化圖像
void MainWindow::updateBinaryImage(int threshold)
{
    binaryImage = applyThreshold(cvGrayImage, threshold);
    displayImage(ui->binaryImageLabel, binaryImage);
}

// 顯示圖像
void MainWindow::displayImage(QLabel *label, const cv::Mat &image) // OpenCV和Qt使用不同的圖像數據表示方式，需要進行格式轉換。
{
    cv::Mat rgbImage;
    if (image.channels() == 1) {
        // 如果圖像是單通道（灰度圖像），則將其轉換為 RGB 格式
        cv::cvtColor(image, rgbImage, cv::COLOR_GRAY2RGB);
    } else {
        // 如果圖像是多通道（假設是 BGR 格式），則將其轉換為 RGB 格式
        cv::cvtColor(image, rgbImage, cv::COLOR_BGR2RGB);
    }
    // 將OpenCV的Mat格式圖像轉回Qt的QImage格式
    QImage qImage(rgbImage.data, rgbImage.cols, rgbImage.rows, rgbImage.step, QImage::Format_RGB888);
    // 將QImage顯示在指定的QLabel上
    label->setPixmap(QPixmap::fromImage(qImage));
}

// 顯示直方圖
void MainWindow::displayHistogram(QLabel *label, const cv::Mat &grayImage)
{
    // 計算直方圖
    int histSize = 256;
    float range[] = {0, 256};
    const float *histRange = {range};
    cv::Mat hist;
    cv::calcHist(&grayImage, 1, 0, cv::Mat(), hist, 1, &histSize, &histRange);

    // 繪製直方圖
    int hist_w = 256; int hist_h = 200;
    int bin_w = cvRound((double) hist_w / histSize);
    cv::Mat histImage(hist_h, hist_w, CV_8UC1, cv::Scalar(255, 255, 255));

    cv::normalize(hist, hist, 0, histImage.rows, cv::NORM_MINMAX, -1, cv::Mat());

    for (int i = 1; i < histSize; i++) {
        cv::line(histImage, cv::Point(bin_w*(i-1), hist_h - cvRound(hist.at<float>(i-1))),
                 cv::Point(bin_w*(i), hist_h - cvRound(hist.at<float>(i))),
                 cv::Scalar(0, 0, 0), 2, 8, 0);
    }
    displayImage(label, histImage);
}

// 使用 Mean 方法灰階化
cv::Mat MainWindow::computeMeanGray(const cv::Mat &image)
{
    cv::Mat gray;
    cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);

    cv::Mat meanGray = cv::Mat::zeros(gray.size(), gray.type());
    cv::Scalar meanValue = cv::mean(gray);
    gray.convertTo(meanGray, gray.type(), 1, -meanValue[0]);

    return meanGray;
}

// 使用 OpenCV 內建灰階化
cv::Mat MainWindow::convertToGray(const cv::Mat &image)
{
    cv::Mat gray;
    cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);
    return gray;
}

// 二值化圖像
cv::Mat MainWindow::applyThreshold(const cv::Mat &grayImage, int threshold)
{
    cv::Mat binary;
    cv::threshold(grayImage, binary, threshold, 255, cv::THRESH_BINARY);
    return binary;
}

// 應用濾鏡
void MainWindow::applyFilters(const cv::Mat &image)
{
    // Filter 1: Blur
    cv::blur(image, filteredImage1, cv::Size(5, 5));
    displayImage(ui->filteredImageLabel1, filteredImage1);

    // Filter 2: Gaussian Blur
    cv::GaussianBlur(image, filteredImage2, cv::Size(5, 5), 0);
    displayImage(ui->filteredImageLabel2, filteredImage2);

    // Filter 3: Edge Detection (Canny)
    cv::Mat edges;
    cv::Canny(image, edges, 100, 200);
    cv::cvtColor(edges, filteredImage3, cv::COLOR_GRAY2BGR); // Convert to 3 channel image
    displayImage(ui->filteredImageLabel3, filteredImage3);
}


