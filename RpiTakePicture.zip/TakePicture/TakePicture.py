import cv2
import RPi.GPIO as GPIO
import time

# 初始化相機和按鈕
cap = cv2.VideoCapture(0)  # 使用第0個設備，即第一個相機
btnPin = 3

# 設置GPIO模式
GPIO.setmode(GPIO.BCM)
GPIO.setup(btnPin, GPIO.IN)
print('Ready')

try:
    GPIO.wait_for_edge(btnPin, GPIO.RISING)
    print ('low voltage changes to high voltage')
    ret, frame = cap.read()
    if ret:
        filename = "/home/pi/photo_{}.jpg".format(int(time.time()))
        cv2.imwrite(filename, frame)
        print("Photo saved as {}".format(filename))
except:  
    print("Other error or exception occurred!" )
finally:  
    GPIO.cleanup()

