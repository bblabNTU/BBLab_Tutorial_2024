#include "mainwindow.h"
#include <QFileDialog>
#include <QColorDialog>
#include <QInputDialog>
#include <QMenuBar>
#include <QAction>
#include <QPainter>
#include <QMouseEvent>
#include <QResizeEvent>

MainWindow::MainWindow()
    : myPenColor(Qt::blue), myPenWidth(1), scribbling(false)
{
    setAttribute(Qt::WA_StaticContents);
    resize(800, 600);

    createActions();
    createMenus();

    setWindowTitle(tr("Simple Drawing App"));
}

void MainWindow::open()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open Image"), "", tr("Images (*.png *.xpm *.jpg)"));
    if (!fileName.isEmpty()) {
        QImage loadedImage;
        if (loadedImage.load(fileName)) {
            QSize newSize = loadedImage.size().expandedTo(size());
            resizeImage(&loadedImage, newSize);
            image = loadedImage;
            update();
        }
    }
}

void MainWindow::penColor()
{
    QColor newColor = QColorDialog::getColor(myPenColor, this);
    if (newColor.isValid())
        myPenColor = newColor;
}

void MainWindow::penWidth()
{
    bool ok;
    int newWidth = QInputDialog::getInt(this, tr("Pen Width"), tr("Select pen width:"), myPenWidth, 1, 50, 1, &ok);
    if (ok)
        myPenWidth = newWidth;
}

void MainWindow::clearImage()
{
    image.fill(Qt::white);  //塗滿白色就clear image了
    update();
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        lastPoint = event->pos();
        scribbling = true;
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if ((event->buttons() & Qt::LeftButton) && scribbling)
        drawLineTo(event->pos());
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && scribbling) {
        drawLineTo(event->pos());
        scribbling = false;
    }
}




void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QRect dirtyRect = event->rect();
    painter.drawImage(dirtyRect, image, dirtyRect);
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    if (width() > image.width() || height() > image.height()) {
        QSize newSize(qMax(width() + 128, image.width()), qMax(height() + 128, image.height()));
        resizeImage(&image, newSize);
        update();
    }
    QMainWindow::resizeEvent(event);
}



void MainWindow::drawLineTo(const QPoint &endPoint)
{
    QPainter painter(&image);
    painter.setPen(QPen(myPenColor, myPenWidth, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    painter.drawLine(lastPoint, endPoint);

    int rad = (myPenWidth / 2) + 2;
    update(QRect(lastPoint, endPoint).normalized().adjusted(-rad, -rad, +rad, +rad));
    lastPoint = endPoint;
}

void MainWindow::resizeImage(QImage *image, const QSize &newSize)
{
    if (image->size() == newSize)
        return;

    QImage newImage(newSize, QImage::Format_RGB32);
    newImage.fill(Qt::white);

    QPainter painter(&newImage);
    painter.drawImage(QPoint(0, 0), *image);
    *image = newImage;
}

void MainWindow::createActions()
{
    openAct = new QAction(tr("&Open..."), this);
    openAct->setShortcuts(QKeySequence::Open); //設置快捷鍵
    connect(openAct, &QAction::triggered, this, &MainWindow::open);

    penColorAct = new QAction(tr("&Pen Color..."), this);
    connect(penColorAct, &QAction::triggered, this, &MainWindow::penColor);

    penWidthAct = new QAction(tr("Pen &Width..."), this);
    connect(penWidthAct, &QAction::triggered, this, &MainWindow::penWidth);

    clearScreenAct = new QAction(tr("&Clear Screen"), this);
    clearScreenAct->setShortcut(tr("Ctrl+L"));
    connect(clearScreenAct, &QAction::triggered, this, &MainWindow::clearImage);
}

void MainWindow::createMenus()
{
    QMenu *fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(openAct);

    QMenu *optionsMenu = menuBar()->addMenu(tr("&Options"));
    optionsMenu->addAction(penColorAct);
    optionsMenu->addAction(penWidthAct);
    optionsMenu->addSeparator();
    optionsMenu->addAction(clearScreenAct);
}
