/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QCheckBox *checkBoxDish1;
    QCheckBox *checkBoxDish2;
    QCheckBox *checkBoxDish3;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QCheckBox *checkBoxAddon1;
    QCheckBox *checkBoxAddon2;
    QCheckBox *checkBoxAddon3;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_3;
    QRadioButton *radioButtonCard;
    QRadioButton *radioButtonCash;
    QLabel *labelTotal;
    QPushButton *pushButtonCancel;
    QPushButton *pushButtonOK;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        QFont font;
        font.setPointSize(18);
        MainWindow->setFont(font);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(290, 0, 231, 91));
        QFont font1;
        font1.setPointSize(25);
        label->setFont(font1);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(130, 90, 71, 21));
        label_2->setFont(font);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(320, 90, 111, 20));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(480, 90, 91, 21));
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(47, 129, 221, 191));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        checkBoxDish1 = new QCheckBox(verticalLayoutWidget);
        checkBoxDish1->setObjectName(QString::fromUtf8("checkBoxDish1"));
        QFont font2;
        font2.setPointSize(16);
        checkBoxDish1->setFont(font2);

        verticalLayout->addWidget(checkBoxDish1);

        checkBoxDish2 = new QCheckBox(verticalLayoutWidget);
        checkBoxDish2->setObjectName(QString::fromUtf8("checkBoxDish2"));
        checkBoxDish2->setFont(font2);

        verticalLayout->addWidget(checkBoxDish2);

        checkBoxDish3 = new QCheckBox(verticalLayoutWidget);
        checkBoxDish3->setObjectName(QString::fromUtf8("checkBoxDish3"));
        checkBoxDish3->setFont(font2);

        verticalLayout->addWidget(checkBoxDish3);

        verticalLayoutWidget_2 = new QWidget(centralwidget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(270, 130, 171, 191));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        checkBoxAddon1 = new QCheckBox(verticalLayoutWidget_2);
        checkBoxAddon1->setObjectName(QString::fromUtf8("checkBoxAddon1"));
        checkBoxAddon1->setFont(font2);

        verticalLayout_2->addWidget(checkBoxAddon1);

        checkBoxAddon2 = new QCheckBox(verticalLayoutWidget_2);
        checkBoxAddon2->setObjectName(QString::fromUtf8("checkBoxAddon2"));
        checkBoxAddon2->setFont(font2);

        verticalLayout_2->addWidget(checkBoxAddon2);

        checkBoxAddon3 = new QCheckBox(verticalLayoutWidget_2);
        checkBoxAddon3->setObjectName(QString::fromUtf8("checkBoxAddon3"));
        checkBoxAddon3->setFont(font2);

        verticalLayout_2->addWidget(checkBoxAddon3);

        verticalLayoutWidget_3 = new QWidget(centralwidget);
        verticalLayoutWidget_3->setObjectName(QString::fromUtf8("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(439, 129, 171, 191));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        radioButtonCard = new QRadioButton(verticalLayoutWidget_3);
        radioButtonCard->setObjectName(QString::fromUtf8("radioButtonCard"));
        radioButtonCard->setEnabled(true);
        radioButtonCard->setFont(font2);

        verticalLayout_3->addWidget(radioButtonCard);

        radioButtonCash = new QRadioButton(verticalLayoutWidget_3);
        radioButtonCash->setObjectName(QString::fromUtf8("radioButtonCash"));
        radioButtonCash->setFont(font2);

        verticalLayout_3->addWidget(radioButtonCash);

        labelTotal = new QLabel(centralwidget);
        labelTotal->setObjectName(QString::fromUtf8("labelTotal"));
        labelTotal->setGeometry(QRect(290, 380, 171, 31));
        pushButtonCancel = new QPushButton(centralwidget);
        pushButtonCancel->setObjectName(QString::fromUtf8("pushButtonCancel"));
        pushButtonCancel->setGeometry(QRect(160, 330, 111, 31));
        pushButtonOK = new QPushButton(centralwidget);
        pushButtonOK->setObjectName(QString::fromUtf8("pushButtonOK"));
        pushButtonOK->setGeometry(QRect(390, 330, 100, 32));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 32));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\351\273\236\351\244\220\347\263\273\347\265\261", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\344\270\273\351\244\220", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\345\212\240\351\273\236", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\344\273\230\346\254\276\346\226\271\345\274\217", nullptr));
        checkBoxDish1->setText(QCoreApplication::translate("MainWindow", "\351\271\275\345\221\263\351\233\236\347\231\275\346\271\257\346\213\211\351\272\265  $200", nullptr));
        checkBoxDish2->setText(QCoreApplication::translate("MainWindow", "\351\233\236\351\206\254\346\262\271\346\213\211\351\272\265  $250", nullptr));
        checkBoxDish3->setText(QCoreApplication::translate("MainWindow", "\346\237\232\351\246\231\346\205\225\346\226\257\351\233\236\347\231\275\346\271\257\346\213\211\351\272\265  $300", nullptr));
        checkBoxAddon1->setText(QCoreApplication::translate("MainWindow", "\346\272\217\345\277\203\350\233\213  $30", nullptr));
        checkBoxAddon2->setText(QCoreApplication::translate("MainWindow", "\345\217\211\347\207\222\351\243\257  $50", nullptr));
        checkBoxAddon3->setText(QCoreApplication::translate("MainWindow", "\345\217\211\347\207\222\346\213\274\347\233\244  $100", nullptr));
        radioButtonCard->setText(QCoreApplication::translate("MainWindow", "\345\210\267\345\215\241 10% off", nullptr));
        radioButtonCash->setText(QCoreApplication::translate("MainWindow", "\347\217\276\351\207\221 20% off", nullptr));
        labelTotal->setText(QString());
        pushButtonCancel->setText(QCoreApplication::translate("MainWindow", "Cancel", nullptr));
        pushButtonOK->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
