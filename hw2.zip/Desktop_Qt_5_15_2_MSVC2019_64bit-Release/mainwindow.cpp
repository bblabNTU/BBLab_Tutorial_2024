#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QApplication>
#include <QMap>
#include <QCheckBox>
#include <QDebug>
#include <QList>
#include <QWidget>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Ordering System");
    QWidget::resize(600,300) ;
}
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_buttonBox_accepted()
{
    double totalprice = 0;
    double discountPrice = 0;
    if(ui->checkBox_blaceTea->isChecked()){
        totalprice += 20;
    }
    if(ui->checkBox_burger->isChecked()){
        totalprice += 50;
    }
    if(ui->checkBox_milkTea->isChecked()){
        totalprice += 30;
    }
    if(ui->checkBox_sandwich->isChecked())
    {
        totalprice += 45;
    }
    if(ui->checkBox_soyMilk->isChecked()){
        totalprice += 25;
    }
    if(ui->checkBox_toast->isChecked()){
        totalprice += 25;
    }

    if(ui->radioButton_cash->isChecked()){
        discountPrice = totalprice*0.9;
    }else if(ui->radioButton_creditCard->isChecked()){
        discountPrice = totalprice*0.7;
    }

    int finalPrice = qRound(discountPrice);

    QString str = "total: ";
    QString priceStr = QString::number(finalPrice);
    ui->label_price->setText(str+priceStr);
}


void MainWindow::on_buttonBox_rejected()
{
    QList<QCheckBox*> checkBoxes = {ui->checkBox_blaceTea, ui->checkBox_burger, ui->checkBox_milkTea,
                                     ui->checkBox_soyMilk, ui->checkBox_sandwich, ui->checkBox_toast};
    for(QCheckBox* checkBox:checkBoxes){
        checkBox->setChecked(false);
    }

    QList<QRadioButton*> radioBoxes = {ui->radioButton_cash, ui->radioButton_creditCard};
    for(QRadioButton* radioBox:radioBoxes){
        radioBox->setAutoExclusive(false);
        radioBox->setChecked(false);
        radioBox->setAutoExclusive(false);
    }
}

