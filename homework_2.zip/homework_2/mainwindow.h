#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QCheckBox>
#include <QSpinBox>
#include <QLabel>
#include <QPushButton>
#include <QRadioButton>

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onOrderClicked();
    void onCancelClicked();

private:
    QCheckBox *checkBoxFries;
    QCheckBox *checkBoxWings;
    QCheckBox *checkBoxSalad;
    QCheckBox *checkBoxToast;
    QCheckBox *checkBoxSteak;
    QCheckBox *checkBoxPasta;
    QCheckBox *checkBoxRice;
    QCheckBox *checkBoxRibs;
    QCheckBox *checkBoxCoke;
    QCheckBox *checkBoxJuice;
    QCheckBox *checkBoxTea;



    QRadioButton *radioCreditCard;
    QRadioButton *radioCash;

    QPushButton *buttonOrder;
    QPushButton *buttonCancel;

    QLabel *labelordering;
};

#endif // MAINWINDOW_H
