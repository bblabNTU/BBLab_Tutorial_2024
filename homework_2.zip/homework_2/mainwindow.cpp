#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>

// 用於設置部件字體大小的輔助函數
void setFontSize(QWidget *widget, int fontSize) {
    QFont font = widget->font();
    font.setPointSize(fontSize);
    widget->setFont(font);
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    checkBoxFries(new QCheckBox("薯條 120")),
    checkBoxWings(new QCheckBox("炸雞翅 160")),
    checkBoxSalad(new QCheckBox("沙拉 150")),
    checkBoxToast(new QCheckBox("起司條 200")),
    checkBoxSteak(new QCheckBox("菲力牛排 880")),
    checkBoxPasta(new QCheckBox("波隆那義大利麵 380")),
    checkBoxRice(new QCheckBox("漢堡 320")),
    checkBoxRibs(new QCheckBox("炭烤豬肋排 660")),
    checkBoxCoke(new QCheckBox("可樂 90")),
    checkBoxJuice(new QCheckBox("柳橙汁 110")),
    checkBoxTea(new QCheckBox("紅茶 100")),
    radioCreditCard(new QRadioButton("信用卡")),
    radioCash(new QRadioButton("現金")),
    buttonOrder(new QPushButton("確定")),
    buttonCancel(new QPushButton("取消")),
    labelordering(new QLabel("點餐系統")) {

    // 設置字體大小
    int titleFontSize = 20;
    int itemFontSize = 16;
    setFontSize(labelordering, titleFontSize);  // 設置標題字體
    setFontSize(checkBoxFries, itemFontSize);
    setFontSize(checkBoxWings, itemFontSize);
    setFontSize(checkBoxSalad, itemFontSize);
    setFontSize(checkBoxToast, itemFontSize);
    setFontSize(checkBoxSteak, itemFontSize);
    setFontSize(checkBoxPasta, itemFontSize);
    setFontSize(checkBoxRice, itemFontSize);
    setFontSize(checkBoxRibs, itemFontSize);
    setFontSize(checkBoxCoke, itemFontSize);
    setFontSize(checkBoxJuice, itemFontSize);
    setFontSize(checkBoxTea, itemFontSize);
    setFontSize(radioCreditCard, itemFontSize);
    setFontSize(radioCash, itemFontSize);
    setFontSize(buttonOrder, itemFontSize);
    setFontSize(buttonCancel, itemFontSize);

    // 設置標題居中
    labelordering->setAlignment(Qt::AlignCenter);

    // 設置佈局
    QVBoxLayout *mainLayout = new QVBoxLayout;

    QHBoxLayout *titleLayout = new QHBoxLayout;
    titleLayout->addWidget(labelordering);
    mainLayout->addLayout(titleLayout);

    QHBoxLayout *appetizerLayout = new QHBoxLayout;
    appetizerLayout->addWidget(checkBoxFries);
    appetizerLayout->addWidget(checkBoxWings);
    appetizerLayout->addWidget(checkBoxSalad);
    appetizerLayout->addWidget(checkBoxToast);
    mainLayout->addLayout(appetizerLayout);

    QHBoxLayout *mainCourseLayout = new QHBoxLayout;
    mainCourseLayout->addWidget(checkBoxSteak);
    mainCourseLayout->addWidget(checkBoxPasta);
    mainCourseLayout->addWidget(checkBoxRice);
    mainCourseLayout->addWidget(checkBoxRibs);
    mainLayout->addLayout(mainCourseLayout);

    QBoxLayout *drinkLayout = new QHBoxLayout;
    drinkLayout->addWidget(checkBoxCoke);
    drinkLayout->addWidget(checkBoxJuice);
    drinkLayout->addWidget(checkBoxTea);
    mainLayout->addLayout(drinkLayout);

    QHBoxLayout *paymentLayout = new QHBoxLayout;
    paymentLayout->addWidget(radioCreditCard);
    paymentLayout->addWidget(radioCash);
    mainLayout->addLayout(paymentLayout);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addWidget(buttonOrder);
    buttonLayout->addWidget(buttonCancel);
    mainLayout->addLayout(buttonLayout);

    QWidget *centralWidget = new QWidget;
    centralWidget->setLayout(mainLayout);
    setCentralWidget(centralWidget);

    // 設置按鈕事件
    connect(buttonOrder, &QPushButton::clicked, this, &MainWindow::onOrderClicked);
    connect(buttonCancel, &QPushButton::clicked, this, &MainWindow::onCancelClicked);
}

MainWindow::~MainWindow() {}

void MainWindow::onCancelClicked() {
    // 清除所有 CheckBox 的選中狀態
    checkBoxFries->setChecked(false);
    checkBoxWings->setChecked(false);
    checkBoxSalad->setChecked(false);
    checkBoxToast->setChecked(false);
    checkBoxSteak->setChecked(false);
    checkBoxPasta->setChecked(false);
    checkBoxRice->setChecked(false);
    checkBoxRibs->setChecked(false);
    checkBoxCoke->setChecked(false);
    checkBoxJuice->setChecked(false);
    checkBoxTea->setChecked(false);

    // 清除付款方式選擇
    radioCreditCard->setChecked(false);
    radioCash->setChecked(false);
}

void MainWindow::onOrderClicked() {
    int totalPrice = 0;
    if (checkBoxFries->isChecked()) {
        totalPrice += 120;
    }
    if (checkBoxWings->isChecked()) {
        totalPrice += 160;
    }
    if (checkBoxSalad->isChecked()) {
        totalPrice += 150;
    }
    if (checkBoxToast->isChecked()) {
        totalPrice += 200;
    }
    if (checkBoxSteak->isChecked()) {
        totalPrice += 880;
    }
    if (checkBoxPasta->isChecked()) {
        totalPrice += 380;
    }
    if (checkBoxRice->isChecked()) {
        totalPrice += 320;
    }
    if (checkBoxRibs->isChecked()) {
        totalPrice += 660;
    }
    if (checkBoxCoke->isChecked()) {
        totalPrice += 90;
    }
    if (checkBoxJuice->isChecked()) {
        totalPrice += 110;
    }
    if (checkBoxTea->isChecked()) {
        totalPrice += 100;
    }

    QString paymentMethod;
    if (radioCreditCard->isChecked()) {
        paymentMethod = "信用卡";
    } else if (radioCash->isChecked()) {
        paymentMethod = "現金";
    } else {
        QMessageBox::warning(this, "錯誤", "請選擇付款方式");
            return;
    }

    QMessageBox::information(this, "總價", QString("總價: %1 元\n付款方式: %2").arg(totalPrice).arg(paymentMethod));
}
