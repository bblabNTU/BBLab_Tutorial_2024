#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QImage>
#include <QPixmap>
#include <QSlider>
#include <opencv2/opencv.hpp>

using namespace cv;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    connect(ui->pushButton_selectImage, &QPushButton::clicked, this, &MainWindow::on_pushButton_selectImage_clicked);
    connect(ui->Slider_threshold, &QSlider::valueChanged, this, &MainWindow::on_Slider_threshold_valueChanged);
    connect(ui->pushButton_applyFilter, &QPushButton::clicked, this, &MainWindow::on_pushButton_applyFilter_clicked);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_pushButton_selectImage_clicked() {
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open Image"), "", tr("Image Files (*.png *.jpg);;All Files (*)"));
    if (!fileName.isEmpty()) {
        colorImage = imread(fileName.toStdString());
        displayImage(ui->label_color, colorImage);

        grayMeanImage = applyGrayMean(colorImage);
        displayImage(ui->label_grayMean, grayMeanImage);

        grayFunctionImage = applyGrayFunction(colorImage);
        displayImage(ui->label_grayFunction, grayFunctionImage);

        applyThreshold(); // 应用阈值并显示
    }
}

void MainWindow::displayImage(QLabel *label, const Mat &image) {
    Mat rgbImage;
    cvtColor(image, rgbImage, COLOR_BGR2RGB);
    QImage qimg(rgbImage.data, rgbImage.cols, rgbImage.rows, rgbImage.step, QImage::Format_RGB888);
    label->setPixmap(QPixmap::fromImage(qimg).scaled(label->size(), Qt::KeepAspectRatio));
}

Mat MainWindow::applyGrayMean(const Mat &image) {
    Mat grayImage = image.clone();
    for (int i = 0; i < grayImage.rows; i++) {
        for (int j = 0; j < grayImage.cols; j++) {
            Vec3b pixel = grayImage.at<Vec3b>(i, j);
            uchar grayValue = static_cast<uchar>(pixel[0] * 0.33 + pixel[1] * 0.33 + pixel[2] * 0.33);
            grayImage.at<Vec3b>(i, j) = Vec3b(grayValue, grayValue, grayValue);
        }
    }
    return grayImage;
}

Mat MainWindow::applyGrayFunction(const Mat &image) {
    Mat grayImage;
    cvtColor(image, grayImage, COLOR_BGR2GRAY);
    return grayImage;
}

void MainWindow::on_Slider_threshold_valueChanged(int value) {
    thresholdVal = value;
    applyThreshold(); // 应用当前阈值
}

void MainWindow::applyThreshold() {
    if (grayFunctionImage.empty()) {
        return;
    }
    cv::Mat binaryImage;
    cv::threshold(grayFunctionImage, binaryImage, thresholdVal, 255, cv::THRESH_BINARY);
    displayImage(ui->label_binary, binaryImage);
}

void MainWindow::on_pushButton_applyFilter_clicked() {
    if (colorImage.empty()) {
        return;
    }

    Mat sepiaImage = applySepiaFilter(colorImage);
    displayImage(ui->label_sepiaImage, sepiaImage);

    Mat vignetteImage = applyVignetteFilter(colorImage);
    displayImage(ui->label_vignetteImage, vignetteImage);

    Mat embossedEdgesImage = applyEmbossedEdgesFilter(colorImage);
    displayImage(ui->label_EmbossedImage, embossedEdgesImage);
}

Mat MainWindow::applySepiaFilter(const Mat &image) {
    Mat sepiaImage = image.clone();

    Mat sepiaKernel = (Mat_<float>(3, 3) << 0.393, 0.769, 0.189,
                       0.349, 0.686, 0.168,
                       0.272, 0.534, 0.131);
    sepiaImage.convertTo(sepiaImage, CV_32F);   // 转换到 CV_32F 类型
    transform(sepiaImage, sepiaImage, sepiaKernel);
    threshold(sepiaImage, sepiaImage, 255, 255, THRESH_TRUNC); // 限制值到 255
    sepiaImage.convertTo(sepiaImage, CV_8U);   // 转回 CV_8U 类型

    return sepiaImage;
}


Mat MainWindow::applyVignetteFilter(const Mat &image, double level) {
    Mat vignetteImage = image.clone();

    Mat kernelX = getGaussianKernel(image.cols, image.cols / level, CV_64F);
    Mat kernelY = getGaussianKernel(image.rows, image.rows / level, CV_64F);
    Mat mask = kernelY * kernelX.t();
    normalize(mask, mask, 0, 1, NORM_MINMAX);

    std::vector<cv::Mat> channels(3);
    split(vignetteImage, channels);

    for (int i = 0; i < 3; i++) {
        channels[i].convertTo(channels[i], CV_64F); //轉換為CV_64F類型
        channels[i] = channels[i].mul(mask);
        channels[i].convertTo(channels[i], CV_8U);  //轉回CV_8U類型
    }
    merge(channels, vignetteImage);

    return vignetteImage;
}


Mat MainWindow::applyEmbossedEdgesFilter(const cv::Mat &image) {
    Mat embossedImage;
    Mat kernel = (cv::Mat_<float>(3, 3) <<  0, -3, -3,
                  3,  0, -3,
                  3,  3,  0);

    filter2D(image, embossedImage, -1, kernel);

    return embossedImage;
}
