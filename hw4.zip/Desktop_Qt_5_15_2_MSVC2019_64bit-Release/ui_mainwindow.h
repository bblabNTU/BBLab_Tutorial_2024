/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QSlider *Slider_threshold;
    QPushButton *pushButton_selectImage;
    QLabel *label_color;
    QLabel *label_grayMean;
    QLabel *label_grayFunction;
    QLabel *label_binary;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QWidget *tab_2;
    QPushButton *pushButton_applyFilter;
    QLabel *label_sepia;
    QLabel *label_vignette;
    QLabel *label_embossedEdges;
    QLabel *label_sepiaImage;
    QLabel *label_vignetteImage;
    QLabel *label_EmbossedImage;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(767, 563);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(10, 10, 731, 471));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        Slider_threshold = new QSlider(tab);
        Slider_threshold->setObjectName(QString::fromUtf8("Slider_threshold"));
        Slider_threshold->setGeometry(QRect(580, 230, 121, 16));
        Slider_threshold->setOrientation(Qt::Horizontal);
        pushButton_selectImage = new QPushButton(tab);
        pushButton_selectImage->setObjectName(QString::fromUtf8("pushButton_selectImage"));
        pushButton_selectImage->setGeometry(QRect(0, 0, 131, 31));
        label_color = new QLabel(tab);
        label_color->setObjectName(QString::fromUtf8("label_color"));
        label_color->setGeometry(QRect(10, 70, 190, 140));
        label_grayMean = new QLabel(tab);
        label_grayMean->setObjectName(QString::fromUtf8("label_grayMean"));
        label_grayMean->setGeometry(QRect(240, 70, 190, 140));
        label_grayFunction = new QLabel(tab);
        label_grayFunction->setObjectName(QString::fromUtf8("label_grayFunction"));
        label_grayFunction->setGeometry(QRect(240, 270, 190, 140));
        label_binary = new QLabel(tab);
        label_binary->setObjectName(QString::fromUtf8("label_binary"));
        label_binary->setGeometry(QRect(530, 70, 190, 140));
        label = new QLabel(tab);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 30, 101, 41));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(tab);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(260, 30, 121, 41));
        label_2->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(tab);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(240, 230, 171, 31));
        label_3->setAlignment(Qt::AlignCenter);
        label_4 = new QLabel(tab);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(530, 30, 101, 41));
        label_4->setAlignment(Qt::AlignCenter);
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        pushButton_applyFilter = new QPushButton(tab_2);
        pushButton_applyFilter->setObjectName(QString::fromUtf8("pushButton_applyFilter"));
        pushButton_applyFilter->setGeometry(QRect(0, 0, 131, 31));
        label_sepia = new QLabel(tab_2);
        label_sepia->setObjectName(QString::fromUtf8("label_sepia"));
        label_sepia->setGeometry(QRect(10, 40, 80, 31));
        label_sepia->setAlignment(Qt::AlignCenter);
        label_vignette = new QLabel(tab_2);
        label_vignette->setObjectName(QString::fromUtf8("label_vignette"));
        label_vignette->setGeometry(QRect(280, 40, 131, 31));
        label_vignette->setAlignment(Qt::AlignCenter);
        label_embossedEdges = new QLabel(tab_2);
        label_embossedEdges->setObjectName(QString::fromUtf8("label_embossedEdges"));
        label_embossedEdges->setGeometry(QRect(520, 40, 181, 31));
        label_embossedEdges->setAlignment(Qt::AlignCenter);
        label_sepiaImage = new QLabel(tab_2);
        label_sepiaImage->setObjectName(QString::fromUtf8("label_sepiaImage"));
        label_sepiaImage->setGeometry(QRect(10, 70, 215, 155));
        label_vignetteImage = new QLabel(tab_2);
        label_vignetteImage->setObjectName(QString::fromUtf8("label_vignetteImage"));
        label_vignetteImage->setGeometry(QRect(260, 90, 215, 155));
        label_EmbossedImage = new QLabel(tab_2);
        label_EmbossedImage->setObjectName(QString::fromUtf8("label_EmbossedImage"));
        label_EmbossedImage->setGeometry(QRect(500, 70, 215, 155));
        tabWidget->addTab(tab_2, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 767, 17));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton_selectImage->setText(QCoreApplication::translate("MainWindow", "select image", nullptr));
        label_color->setText(QString());
        label_grayMean->setText(QString());
        label_grayFunction->setText(QString());
        label_binary->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "original image", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "gray mean image", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "gray function image", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "binary image", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "gray scale/binary", nullptr));
        pushButton_applyFilter->setText(QCoreApplication::translate("MainWindow", "apply filters", nullptr));
        label_sepia->setText(QCoreApplication::translate("MainWindow", "Sepia Filter", nullptr));
        label_vignette->setText(QCoreApplication::translate("MainWindow", "Vignette Filter", nullptr));
        label_embossedEdges->setText(QCoreApplication::translate("MainWindow", "Embossed Edges Filter", nullptr));
        label_sepiaImage->setText(QString());
        label_vignetteImage->setText(QString());
        label_EmbossedImage->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("MainWindow", "filter", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
