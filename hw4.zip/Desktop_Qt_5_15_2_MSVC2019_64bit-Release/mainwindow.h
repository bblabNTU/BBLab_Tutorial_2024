#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <opencv2/opencv.hpp> // 修正包含路径

QT_BEGIN_NAMESPACE
using namespace cv;
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_selectImage_clicked();
    void on_Slider_threshold_valueChanged(int value);
    void on_pushButton_applyFilter_clicked();

private:
    Ui::MainWindow *ui;
    void displayImage(QLabel *label, const Mat &image);
    Mat applyGrayMean(const Mat &image);
    Mat applyGrayFunction(const Mat &image);
    void applyThreshold(); // 修改为无参数
    Mat applySepiaFilter(const Mat &image);
    Mat applyVignetteFilter(const Mat &image, double level = 2.0);
    Mat applyEmbossedEdgesFilter(const Mat &image);

    Mat colorImage;
    Mat grayMeanImage;
    Mat grayFunctionImage;
    Mat binaryImage;

    int thresholdVal;
};

#endif // MAINWINDOW_H
