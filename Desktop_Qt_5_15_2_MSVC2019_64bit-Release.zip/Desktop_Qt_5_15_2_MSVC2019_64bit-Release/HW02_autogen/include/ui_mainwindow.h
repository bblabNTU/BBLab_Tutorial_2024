/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QCheckBox *checkBox_pestopasta;
    QCheckBox *checkBox_burger;
    QCheckBox *checkBox_egg;
    QCheckBox *checkBox_coke;
    QCheckBox *checkBox_sprite;
    QCheckBox *checkBox_Blacktea;
    QRadioButton *radioButton_credit;
    QRadioButton *radioButton_cash;
    QDialogButtonBox *buttonBox;
    QLineEdit *lineEdit;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(664, 474);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        checkBox_pestopasta = new QCheckBox(centralwidget);
        checkBox_pestopasta->setObjectName(QString::fromUtf8("checkBox_pestopasta"));
        checkBox_pestopasta->setGeometry(QRect(70, 90, 181, 23));
        QFont font;
        font.setPointSize(10);
        checkBox_pestopasta->setFont(font);
        checkBox_burger = new QCheckBox(centralwidget);
        checkBox_burger->setObjectName(QString::fromUtf8("checkBox_burger"));
        checkBox_burger->setGeometry(QRect(70, 140, 141, 23));
        checkBox_burger->setFont(font);
        checkBox_egg = new QCheckBox(centralwidget);
        checkBox_egg->setObjectName(QString::fromUtf8("checkBox_egg"));
        checkBox_egg->setGeometry(QRect(70, 190, 151, 23));
        checkBox_egg->setFont(font);
        checkBox_coke = new QCheckBox(centralwidget);
        checkBox_coke->setObjectName(QString::fromUtf8("checkBox_coke"));
        checkBox_coke->setGeometry(QRect(290, 90, 94, 23));
        checkBox_coke->setFont(font);
        checkBox_sprite = new QCheckBox(centralwidget);
        checkBox_sprite->setObjectName(QString::fromUtf8("checkBox_sprite"));
        checkBox_sprite->setGeometry(QRect(290, 140, 94, 23));
        checkBox_sprite->setFont(font);
        checkBox_Blacktea = new QCheckBox(centralwidget);
        checkBox_Blacktea->setObjectName(QString::fromUtf8("checkBox_Blacktea"));
        checkBox_Blacktea->setGeometry(QRect(290, 190, 94, 23));
        checkBox_Blacktea->setFont(font);
        radioButton_credit = new QRadioButton(centralwidget);
        radioButton_credit->setObjectName(QString::fromUtf8("radioButton_credit"));
        radioButton_credit->setGeometry(QRect(470, 90, 114, 23));
        radioButton_credit->setFont(font);
        radioButton_cash = new QRadioButton(centralwidget);
        radioButton_cash->setObjectName(QString::fromUtf8("radioButton_cash"));
        radioButton_cash->setGeometry(QRect(470, 140, 114, 23));
        radioButton_cash->setFont(font);
        buttonBox = new QDialogButtonBox(centralwidget);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(390, 360, 193, 28));
        buttonBox->setAutoFillBackground(false);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox->setCenterButtons(false);
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(60, 320, 161, 31));
        lineEdit->setReadOnly(true);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 664, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        checkBox_pestopasta->setText(QCoreApplication::translate("MainWindow", "\351\235\222\351\206\254\347\276\251\345\244\247\345\210\251\351\272\265$200", nullptr));
        checkBox_burger->setText(QCoreApplication::translate("MainWindow", "\351\256\252\351\255\232\350\233\213\345\240\241$180", nullptr));
        checkBox_egg->setText(QCoreApplication::translate("MainWindow", "\347\217\255\345\260\274\350\277\252\345\205\213\350\233\213$160", nullptr));
        checkBox_coke->setText(QCoreApplication::translate("MainWindow", "\345\217\257\346\250\202$60", nullptr));
        checkBox_sprite->setText(QCoreApplication::translate("MainWindow", "\351\233\252\347\242\247$50", nullptr));
        checkBox_Blacktea->setText(QCoreApplication::translate("MainWindow", "\347\264\205\350\214\266$40", nullptr));
        radioButton_credit->setText(QCoreApplication::translate("MainWindow", "\345\210\267\345\215\24110%off", nullptr));
        radioButton_cash->setText(QCoreApplication::translate("MainWindow", "\347\217\276\351\207\221$30off", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
