#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    int total = 0;

private slots:
    void on_buttonBox_accepted();

    void on_checkBox_pestopasta_stateChanged(int arg1);

    void on_checkBox_burger_stateChanged(int arg1);

    void on_checkBox_egg_stateChanged(int arg1);

    void on_checkBox_coke_stateChanged(int arg1);

    void on_checkBox_sprite_stateChanged(int arg1);

    void on_checkBox_Blacktea_stateChanged(int arg1);

    void on_radioButton_credit_clicked();

    void on_radioButton_cash_clicked();


    void on_buttonBox_rejected();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
