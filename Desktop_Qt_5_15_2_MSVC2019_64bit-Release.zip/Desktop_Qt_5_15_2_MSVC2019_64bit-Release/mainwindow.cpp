#include "mainwindow.h"
#include "./ui_mainwindow.h"
#define _USE_MATH_DEFINES
#include <math.h>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Ordering System");
    int total = 0;
    extern int total;
}



void MainWindow::on_buttonBox_accepted()
{
    ui->lineEdit->setText(QString::number(total));

}


void MainWindow::on_checkBox_pestopasta_stateChanged(int arg1)
{
    arg1 = 200;
    total += arg1;
}


void MainWindow::on_checkBox_burger_stateChanged(int arg1)
{
    arg1 = 180;
    total = total + arg1;
}


void MainWindow::on_checkBox_egg_stateChanged(int arg1)
{
    arg1 = 160;
    total = total + arg1;
}


void MainWindow::on_checkBox_coke_stateChanged(int arg1)
{
    arg1 = 60;
    total = total + arg1;
}


void MainWindow::on_checkBox_sprite_stateChanged(int arg1)
{
    arg1 = 50;
    total = total + arg1;
}


void MainWindow::on_checkBox_Blacktea_stateChanged(int arg1)
{
    arg1 = 40;
    total = total + arg1;
}


void MainWindow::on_radioButton_credit_clicked()
{
    total = total*0.9;
}


void MainWindow::on_radioButton_cash_clicked()
{
    total = total - 30;
}

void MainWindow::on_buttonBox_rejected()
{
    ui->checkBox_Blacktea->setChecked(false);
    ui->checkBox_burger->setChecked(false);
    ui->checkBox_egg->setChecked(false);
    ui->checkBox_pestopasta->setChecked(false);
    ui->checkBox_sprite->setChecked(false);
    ui->checkBox_coke->setChecked(false);
    ui->radioButton_cash->setChecked(false);
    ui->radioButton_cash->setChecked(false);
    ui->radioButton_credit->setChecked(false);
    total = 0;
    ui->lineEdit->clear();
}
MainWindow::~MainWindow()
{
    delete ui;
}



