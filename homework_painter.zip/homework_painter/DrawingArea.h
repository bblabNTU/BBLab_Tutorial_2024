#ifndef DRAWINGAREA_H
#define DRAWINGAREA_H

#include <QWidget>
#include <QColor>
#include <QVector>
#include <QPoint>
#include <QPixmap>

class DrawingArea : public QWidget {
    Q_OBJECT

public:
    explicit DrawingArea(QWidget *parent = nullptr);
    void setColor(const QColor &color);
    void setThickness(int thickness);
    void setBackground(const QString &imagePath);
    void clearLines();  // 清除所有線條

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

private:
    QColor currentColor;
    int currentThickness;
    QPoint startPoint;
    QPoint endPoint;
    QPixmap backgroundPixmap;

    struct Line {
        QPoint start;
        QPoint end;
        QColor color;
        int thickness;
    };

    QVector<Line> lines;  // 儲存繪製的線條
};

#endif // DRAWINGAREA_H
