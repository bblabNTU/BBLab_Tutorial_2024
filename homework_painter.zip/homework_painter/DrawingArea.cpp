#include "DrawingArea.h"
#include <QPainter>
#include <QMouseEvent>
#include <QDir>
#include <QDebug>

DrawingArea::DrawingArea(QWidget *parent)
    : QWidget(parent), currentColor(Qt::black), currentThickness(1) {}

void DrawingArea::setColor(const QColor &color) {
    currentColor = color;
}

void DrawingArea::setThickness(int thickness) {
    currentThickness = thickness;
}

void DrawingArea::setBackground(const QString &imagePath) {
    QString relativePath = "../../../lekne.jpg";  // 調整為正確的相對路徑
    qDebug() << "Loading background image from:" << relativePath;
    if (!backgroundPixmap.load(relativePath)) {
        qDebug() << "Failed to load background image from:" << relativePath;
    } else {
        qDebug() << "Successfully loaded background image.";
    }
    update();
}



void DrawingArea::clearLines() {
    lines.clear();  // 清除所有線條
    update();  // 觸發重繪事件
}

void DrawingArea::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);  // 處理未使用的參數警告

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    if (!backgroundPixmap.isNull()) {
        qDebug() << "Drawing background image.";
        painter.drawPixmap(0, 0, width(), height(), backgroundPixmap);
    } else {
        qDebug() << "Background image is null.";
    }

    for (const auto &line : lines) {
        QPen pen(line.color, line.thickness);
        painter.setPen(pen);
        painter.drawLine(line.start, line.end);
    }
}

void DrawingArea::mousePressEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton) {
        startPoint = event->pos();
    }
}

void DrawingArea::mouseMoveEvent(QMouseEvent *event) {
    if (event->buttons() & Qt::LeftButton) {
        endPoint = event->pos();
        lines.append({startPoint, endPoint, currentColor, currentThickness});
        startPoint = endPoint;
        update();
    }
}

void DrawingArea::mouseReleaseEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton) {
        endPoint = event->pos();
        lines.append({startPoint, endPoint, currentColor, currentThickness});
        update();
    }
}
