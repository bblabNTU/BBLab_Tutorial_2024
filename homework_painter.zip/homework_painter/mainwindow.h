#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QComboBox>
#include <QColorDialog>
#include "DrawingArea.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void chooseColor();
    void setThickness(const QString &thickness);
    void clearLines();  // 添加清除線條的槽函數

private:
    Ui::MainWindow *ui;
    DrawingArea *drawingArea;
    QColor currentColor;
    int currentThickness;
};

#endif // MAINWINDOW_H
