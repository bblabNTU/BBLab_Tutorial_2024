#include "MainWindow.h"
#include "DrawingArea.h"
#include "ui_MainWindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QDir>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , currentColor(Qt::black)
    , currentThickness(1)
{
    ui->setupUi(this);

    // 創建中央小部件和佈局
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    // 創建按鈕和下拉框
    QPushButton *clearButton = new QPushButton("清除", this);
    QPushButton *colorButton = new QPushButton("選擇顏色", this);
    QComboBox *thicknessComboBox = new QComboBox(this);
    thicknessComboBox->addItem("1");
    thicknessComboBox->addItem("2");
    thicknessComboBox->addItem("3");

    // 將按鈕和下拉框添加到水平佈局
    QHBoxLayout *controlsLayout = new QHBoxLayout();
    controlsLayout->addWidget(colorButton);
    controlsLayout->addWidget(thicknessComboBox);
    controlsLayout->addWidget(clearButton);

    // 創建繪圖區域
    drawingArea = new DrawingArea(this);
    drawingArea->setBackground("lekne.jpg");  // 使用相對路徑設置你的圖像路徑

    // 將控制佈局和繪圖區域添加到主佈局
    mainLayout->addLayout(controlsLayout);
    mainLayout->addWidget(drawingArea);

    // 設置中央小部件
    setCentralWidget(centralWidget);

    // 連接信號和槽
    connect(colorButton, &QPushButton::clicked, this, &MainWindow::chooseColor);
    connect(thicknessComboBox, &QComboBox::currentTextChanged, this, &MainWindow::setThickness);
    connect(clearButton, &QPushButton::clicked, this, &MainWindow::clearLines);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::chooseColor() {
    QColor color = QColorDialog::getColor(currentColor, this, "選擇顏色");
    if (color.isValid()) {
        currentColor = color;
        drawingArea->setColor(currentColor);
    }
}

void MainWindow::setThickness(const QString &thickness) {
    currentThickness = thickness.toInt();
    drawingArea->setThickness(currentThickness);
}

void MainWindow::clearLines() {
    drawingArea->clearLines();  // 調用繪圖區域的清除線條函數
}
