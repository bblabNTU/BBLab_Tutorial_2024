"""  
記得把解譯器interpreter改成YOLOv8
"""
from ultralytics import YOLO

# 載入訓練好的模型
model = YOLO('非洲草原動物偵測.pt')

# 使用模型對圖片進行推理
results = model('wild animal.jpg')

# 取出第一個結果（推理的結果會是一個list）
results = results[0]  

# 顯示和儲存結果
results.show()
results.save(filename='result.jpg')  