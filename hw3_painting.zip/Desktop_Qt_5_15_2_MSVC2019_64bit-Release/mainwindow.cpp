#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMouseEvent>
#include <QPainter>
#include <QColorDialog>
#include <QPixmap>
#include <QInputDialog>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , drawing(false)
{
    ui->setupUi(this);
    this->setWindowTitle("painting window");
    this->resize(850, 550);

    canvas = QPixmap(850, 450);
    canvas.fill(QColor(Qt::white));

    label = new QLabel(this);
    label->setGeometry(0, 0, 850, 450);
    label->setPixmap(canvas);

    //初始的畫筆設置
    pen.setColor(Qt::blue);
    pen.setWidth(3);

    //建立按鈕
    buttonColor = new QPushButton("Color", this);
    buttonWidth = new QPushButton("Width", this);
    buttonLoad = new QPushButton("Load", this);
    buttonClear = new QPushButton("Clear", this);
    buttonSave = new QPushButton("Save", this);

    connect(buttonColor, &QPushButton::clicked, this, &MainWindow::on_pushButton_color_clicked);
    connect(buttonWidth, &QPushButton::clicked, this, &MainWindow::on_pushButton_width_clicked);
    connect(buttonLoad, &QPushButton::clicked, this, &MainWindow::on_pushButton_load_clicked);
    connect(buttonClear, &QPushButton::clicked, this, &MainWindow::on_pushButton_clear_clicked);
    connect(buttonSave, &QPushButton::clicked, this, &MainWindow::on_pushButton_save_clicked);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(label);

    QWidget *buttonContainer = new QWidget(this);
    buttonContainer->setFixedSize(500, 50);

    QHBoxLayout *buttonLayout = new QHBoxLayout(buttonContainer);
    buttonLayout->addWidget(buttonColor);
    buttonLayout->addWidget(buttonWidth);
    buttonLayout->addWidget(buttonLoad);
    buttonLayout->addWidget(buttonClear);
    buttonLayout->addWidget(buttonSave);

    mainLayout->addWidget(buttonContainer);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(mainLayout);
    this->setCentralWidget(centralWidget);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton){    //確認有按下左鍵
        lastPoint = event->pos();   //更新滑鼠最後所在位置
        drawing = true; //開始畫圖
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event){
    if(drawing){
        QPainter painter(&canvas);
        painter.setPen(pen);
        painter.drawLine(lastPoint, event->pos());
        lastPoint = event->pos();   //滑鼠的座標位置
        label->setPixmap(canvas);
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event){
    if(event->buttons()==Qt::LeftButton && drawing){
        QPainter painter(&canvas);
        painter.setPen(pen);
        painter.drawLine(lastPoint, event->pos());
        label->setPixmap(canvas);
        drawing = false;    //停止畫圖
    }
}

void MainWindow::on_pushButton_color_clicked()
{
    QColor color = QColorDialog::getColor(pen.color(), this, "select pen color:");
    if(color.isValid()){
        pen.setColor(color);
    }
}


void MainWindow::on_pushButton_width_clicked()
{
    bool ok;    //確認使用者所選的筆刷大小是在範圍內的(1-50)
    int width = QInputDialog::getInt(this, tr("pen width"), tr("select pen width:"), pen.width(),1, 50, 1, &ok);
    if(ok){
        pen.setWidth(width);    //設定筆刷大小
    }
}


void MainWindow::on_pushButton_load_clicked()   //開啟檔案
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("open image")," ", tr("(*.png),(*.jpg);;All Files(*)"));
    if(!fileName.isEmpty()){
        QPixmap newCanvas;
        if(newCanvas.load(fileName)){
            canvas = newCanvas.scaled(800, 450, Qt::KeepAspectRatio);   //將所選檔案放在中間
            label->setPixmap(canvas);
        }
    }
}

void MainWindow::on_pushButton_clear_clicked()
{
    canvas.fill(Qt::white); //畫布區用白色填滿
    label->setPixmap(canvas);
}


void MainWindow::on_pushButton_save_clicked()   //存檔
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("save image")," ", tr(".png,.jpg,.bmp"));
    if(!fileName.isEmpty()){
        canvas.save(fileName);
    }
}

