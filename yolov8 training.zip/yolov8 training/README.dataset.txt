# car and people  > 2024-08-14 6:54am
https://universe.roboflow.com/julio-ml/car-and-people-xsutg

Provided by a Roboflow user
License: CC BY 4.0

