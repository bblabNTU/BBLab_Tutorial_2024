/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_meal;
    QLabel *label_drink;
    QLabel *label_payment;
    QDialogButtonBox *buttonBox;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_4;
    QCheckBox *checkBox_burger;
    QCheckBox *checkBox_sandwich;
    QCheckBox *checkBox_toast;
    QVBoxLayout *verticalLayout_5;
    QCheckBox *checkBox_blaceTea;
    QCheckBox *checkBox_milkTea;
    QCheckBox *checkBox_soyMilk;
    QVBoxLayout *verticalLayout_6;
    QRadioButton *radioButton_cash;
    QRadioButton *radioButton_creditCard;
    QLabel *label_price;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(602, 283);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(220, 8, 191, 31));
        QFont font;
        font.setPointSize(14);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(110, 48, 371, 31));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_meal = new QLabel(layoutWidget);
        label_meal->setObjectName(QString::fromUtf8("label_meal"));
        QFont font1;
        font1.setPointSize(10);
        label_meal->setFont(font1);
        label_meal->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_meal);

        label_drink = new QLabel(layoutWidget);
        label_drink->setObjectName(QString::fromUtf8("label_drink"));
        label_drink->setFont(font1);
        label_drink->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_drink);

        label_payment = new QLabel(layoutWidget);
        label_payment->setObjectName(QString::fromUtf8("label_payment"));
        label_payment->setFont(font1);
        label_payment->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_payment);

        buttonBox = new QDialogButtonBox(centralwidget);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(150, 208, 171, 31));
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_2 = new QWidget(centralwidget);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(80, 78, 441, 121));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        checkBox_burger = new QCheckBox(layoutWidget_2);
        checkBox_burger->setObjectName(QString::fromUtf8("checkBox_burger"));

        verticalLayout_4->addWidget(checkBox_burger);

        checkBox_sandwich = new QCheckBox(layoutWidget_2);
        checkBox_sandwich->setObjectName(QString::fromUtf8("checkBox_sandwich"));

        verticalLayout_4->addWidget(checkBox_sandwich);

        checkBox_toast = new QCheckBox(layoutWidget_2);
        checkBox_toast->setObjectName(QString::fromUtf8("checkBox_toast"));

        verticalLayout_4->addWidget(checkBox_toast);


        horizontalLayout_4->addLayout(verticalLayout_4);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        checkBox_blaceTea = new QCheckBox(layoutWidget_2);
        checkBox_blaceTea->setObjectName(QString::fromUtf8("checkBox_blaceTea"));

        verticalLayout_5->addWidget(checkBox_blaceTea);

        checkBox_milkTea = new QCheckBox(layoutWidget_2);
        checkBox_milkTea->setObjectName(QString::fromUtf8("checkBox_milkTea"));

        verticalLayout_5->addWidget(checkBox_milkTea);

        checkBox_soyMilk = new QCheckBox(layoutWidget_2);
        checkBox_soyMilk->setObjectName(QString::fromUtf8("checkBox_soyMilk"));

        verticalLayout_5->addWidget(checkBox_soyMilk);


        horizontalLayout_4->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        radioButton_cash = new QRadioButton(layoutWidget_2);
        radioButton_cash->setObjectName(QString::fromUtf8("radioButton_cash"));

        verticalLayout_6->addWidget(radioButton_cash);

        radioButton_creditCard = new QRadioButton(layoutWidget_2);
        radioButton_creditCard->setObjectName(QString::fromUtf8("radioButton_creditCard"));

        verticalLayout_6->addWidget(radioButton_creditCard);


        horizontalLayout_4->addLayout(verticalLayout_6);

        label_price = new QLabel(centralwidget);
        label_price->setObjectName(QString::fromUtf8("label_price"));
        label_price->setGeometry(QRect(370, 210, 91, 20));
        QFont font2;
        font2.setPointSize(12);
        label_price->setFont(font2);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 602, 17));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\351\273\236\351\244\220\347\263\273\347\265\261", nullptr));
        label_meal->setText(QCoreApplication::translate("MainWindow", "\351\244\220\351\273\236", nullptr));
        label_drink->setText(QCoreApplication::translate("MainWindow", "\351\243\262\346\226\231", nullptr));
        label_payment->setText(QCoreApplication::translate("MainWindow", "\344\273\230\346\254\276\346\226\271\345\274\217", nullptr));
        checkBox_burger->setText(QCoreApplication::translate("MainWindow", "\350\261\254\346\216\222\346\274\242\345\240\241 $50", nullptr));
        checkBox_sandwich->setText(QCoreApplication::translate("MainWindow", "\347\207\273\351\233\236\344\270\211\346\230\216\346\262\273 $45", nullptr));
        checkBox_toast->setText(QCoreApplication::translate("MainWindow", "\345\267\247\345\205\213\345\212\233\345\216\232\347\211\207 $25", nullptr));
        checkBox_blaceTea->setText(QCoreApplication::translate("MainWindow", "\347\264\205\350\214\266 $20", nullptr));
        checkBox_milkTea->setText(QCoreApplication::translate("MainWindow", "\345\245\266\350\214\266  $30", nullptr));
        checkBox_soyMilk->setText(QCoreApplication::translate("MainWindow", "\350\261\206\346\274\277 $25", nullptr));
        radioButton_cash->setText(QCoreApplication::translate("MainWindow", "\344\273\230\347\217\276 (10% off)", nullptr));
        radioButton_creditCard->setText(QCoreApplication::translate("MainWindow", "\345\210\267\345\215\241 (30%off)", nullptr));
        label_price->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
