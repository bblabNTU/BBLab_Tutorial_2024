#include "DrawingArea.h"
#include <QPainter>
#include <QImage>
#include <QDebug>

DrawingArea::DrawingArea(QWidget *parent)
    : QWidget(parent) {}

void DrawingArea::loadImage(const QString &imagePath) {
    originalImage = cv::imread(imagePath.toStdString());
    if (originalImage.empty()) {
        qDebug() << "Failed to load image";
        return;
    }
    qOriginalImage = QImage(originalImage.data, originalImage.cols, originalImage.rows, originalImage.step, QImage::Format_BGR888);

    computeMeanGrayImage();
    computeFunctionGrayImage();
}

void DrawingArea::computeMeanGrayImage() {
    if (originalImage.empty()) return;
    cv::cvtColor(originalImage, meanGrayImage, cv::COLOR_BGR2GRAY);
    qMeanGrayImage = QImage(meanGrayImage.data, meanGrayImage.cols, meanGrayImage.rows, meanGrayImage.step, QImage::Format_Grayscale8);
}

void DrawingArea::computeFunctionGrayImage() {
    if (originalImage.empty()) return;
    functionGrayImage.create(originalImage.rows, originalImage.cols, CV_8UC1);
    for (int y = 0; y < originalImage.rows; y++) {
        for (int x = 0; x < originalImage.cols; x++) {
            cv::Vec3b intensity = originalImage.at<cv::Vec3b>(y, x);
            uchar gray = static_cast<uchar>(0.299 * intensity[2] + 0.587 * intensity[1] + 0.114 * intensity[0]);
            functionGrayImage.at<uchar>(y, x) = gray;
        }
    }
    qFunctionGrayImage = QImage(functionGrayImage.data, functionGrayImage.cols, functionGrayImage.rows, functionGrayImage.step, QImage::Format_Grayscale8);
}

void DrawingArea::updateImage(int threshold) {
    if (meanGrayImage.empty()) return;
    cv::threshold(meanGrayImage, binaryImage, threshold, 255, cv::THRESH_BINARY);
    qBinaryImage = QImage(binaryImage.data, binaryImage.cols, binaryImage.rows, binaryImage.step, QImage::Format_Grayscale8);
    update();
}

void DrawingArea::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);

    QPainter painter(this);
    int width = this->width() / 2;
    int height = this->height() / 2;

    if (!qOriginalImage.isNull()) {
        QImage scaledImage = qOriginalImage.scaled(width, height, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        painter.drawImage(0, 0, scaledImage);
    }

    if (!qMeanGrayImage.isNull()) {
        QImage scaledImage = qMeanGrayImage.scaled(width, height, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        painter.drawImage(width, 0, scaledImage);
    }

    if (!qFunctionGrayImage.isNull()) {
        QImage scaledImage = qFunctionGrayImage.scaled(width, height, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        painter.drawImage(0, height, scaledImage);
    }

    if (!qBinaryImage.isNull()) {
        QImage scaledImage = qBinaryImage.scaled(width, height, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        painter.drawImage(width, height, scaledImage);
    }
}
