#ifndef DRAWINGAREA_H
#define DRAWINGAREA_H

#include <QWidget>
#include <opencv2/opencv.hpp>

class DrawingArea : public QWidget {
    Q_OBJECT

public:
    explicit DrawingArea(QWidget *parent = nullptr);
    void loadImage(const QString &imagePath);
    void updateImage(int threshold);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    cv::Mat originalImage;
    cv::Mat meanGrayImage;
    cv::Mat functionGrayImage;
    cv::Mat binaryImage;
    QImage qOriginalImage;
    QImage qMeanGrayImage;
    QImage qFunctionGrayImage;
    QImage qBinaryImage;

    void computeMeanGrayImage();
    void computeFunctionGrayImage();
};

#endif // DRAWINGAREA_H
