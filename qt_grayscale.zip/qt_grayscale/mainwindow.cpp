#include "MainWindow.h"
#include "DrawingArea.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFileDialog>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);

    drawingArea = new DrawingArea(this);
    layout->addWidget(drawingArea);

    thresholdSlider = new QSlider(Qt::Horizontal, this);
    thresholdSlider->setRange(0, 255);
    thresholdSlider->setValue(128);
    connect(thresholdSlider, &QSlider::valueChanged, this, &MainWindow::thresholdChanged);
    layout->addWidget(thresholdSlider);

    loadImageButton = new QPushButton("Load Image", this);
    connect(loadImageButton, &QPushButton::clicked, this, &MainWindow::loadImage);
    layout->addWidget(loadImageButton);

    setCentralWidget(centralWidget);
}

MainWindow::~MainWindow() {}

void MainWindow::thresholdChanged(int value) {
    drawingArea->updateImage(value);
}

void MainWindow::loadImage() {
    QString imagePath = QFileDialog::getOpenFileName(this, "Open Image File", "", "Images (*.png *.jpg *.bmp)");
    if (!imagePath.isEmpty()) {
        drawingArea->loadImage(imagePath);
        drawingArea->updateImage(thresholdSlider->value());  // 使用當前閾值更新圖像
    }
}
