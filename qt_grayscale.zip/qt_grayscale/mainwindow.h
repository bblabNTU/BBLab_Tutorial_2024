#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSlider>
#include <QPushButton>
#include "DrawingArea.h"

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void thresholdChanged(int value);
    void loadImage();  // 新增的槽函數

private:
    DrawingArea *drawingArea;
    QSlider *thresholdSlider;
    QPushButton *loadImageButton;  // 新增的按鈕
};

#endif // MAINWINDOW_H
