#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    //初始化變數
    , total(0)
    , press_ham(false), press_noodle(false), press_rice(false) //false代表尚未按過
    , press_cola(false), press_sprite(false), press_BlackTea(false)
    , discount(1.0)
{
    ui->setupUi(this);
    this->setWindowTitle("Ordering System");
    connect(ui->pushButton_Cancel, &QPushButton::clicked, this, &MainWindow::resetAll); //把按按鈕的signal跟resetAll這個slot連接
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_checkBox_hamburger_stateChanged(int arg1)
{
    //通過press記錄按鈕被按下的狀態是勾選還是取消判斷商品是購買還是移除
    if(press_ham == false){
        total += 10;
        press_ham = true;
    }
    else {
        total -= 10;
        press_ham = false;
    }
}


void MainWindow::on_checkBox_noodle_stateChanged(int arg1)
{
    if(press_noodle == false){
        total += 350;
        press_noodle = true;
    }
    else {
        total -= 350;
        press_noodle = false;
    }
}


void MainWindow::on_checkBox_rice_stateChanged(int arg1)
{
    if(press_rice == false){
        total += 350;
        press_rice = true;
    }
    else {
        total -= 350;
        press_rice = false;
    }
}


void MainWindow::on_checkBox_Cola_stateChanged(int arg1)
{
    if(press_cola == false){
        total += 180;
        press_cola = true;
    }
    else {
        total -= 180;
        press_cola = false;
    }
}


void MainWindow::on_checkBox_Sprite_stateChanged(int arg1)
{
    if(press_sprite == false){
        total += 180;
        press_sprite = true;
    }
    else {
        total -= 180;
        press_sprite = false;
    }
}


void MainWindow::on_checkBox_BlackTea_stateChanged(int arg1)
{
    if(press_BlackTea == false){
        total += 100;
        press_BlackTea = true;
    }
    else {
        total -= 100;
        press_BlackTea = false;
    }
}


void MainWindow::on_radioButton_Card_clicked(bool checked) //radioButton可以直接判斷該按鈕有無被勾選(和前面checkBox不同)
{
    if(checked){
        discount = 0.9;
    }
}


void MainWindow::on_radioButton_Cash_clicked(bool checked)
{
    if(checked){
        discount = 0.8;
    }
}


void MainWindow::on_pushButton_OK_clicked()
{
    double final_total = total * discount;
    ui->label_total->setText("total is " + QString::number(final_total)); //Qstring::number轉換數字成QString
    ui->label_recount->setText("請按Cancel以重新計算");
    ui->pushButton_OK->setEnabled(false); //setEnabled控制按鈕能不能被使用
    discount = 1.0;
}


void MainWindow::on_pushButton_Cancel_clicked()
{
    ui->pushButton_OK->setEnabled(true);
    resetAll();
}

void MainWindow::resetAll()
{
    total = 0;
    press_ham = press_noodle = press_rice = false;
    press_cola = press_sprite = press_BlackTea = false;
    discount = 1.0;

    //重置所有QCheckBox
    /*
       findChildren<QCheckBox *>()用於在當前物件的子控件中查找指定類型（或標記）的控件。
       在這裡表示查找所有子控件中類型為 QCheckBox 的控件，並返回一個列表（QList）。

       將返回的 QList<QCheckBox *> 命名為 checkBoxes，然後使用 for 迴圈遍歷這個列表中的每個 QCheckBox 控件。

       對於每個 QCheckBox *checkBox，調用 checkBox->setChecked(false) 函式將其選中狀態設置為 false。取消所有找到的 QCheckBox 控件的選中狀態
    */
    QList<QCheckBox *> checkBoxes = findChildren<QCheckBox *>();
    for (QCheckBox *checkBox : checkBoxes) {
        checkBox->setChecked(false);
    }
    //重置所有QRadioButton
    /*
       AutoExclusive控制radioButton能否複選
       為了重置radioButton需要關閉複選才行（不知為啥
       關閉後重新開啟就好
    */
    ui->radioButton_Card->setAutoExclusive(false);
    ui->radioButton_Card->setChecked(false);
    ui->radioButton_Cash->setAutoExclusive(false);
    ui->radioButton_Cash->setChecked(false);
    ui->radioButton_Card->setAutoExclusive(true);
    ui->radioButton_Cash->setAutoExclusive(true);
    //重置所有label
    ui->label_total->clear();
    ui->label_recount->clear();
}

