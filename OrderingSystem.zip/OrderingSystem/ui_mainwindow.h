/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label_Title;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_Pay;
    QLabel *label_Pay;
    QRadioButton *radioButton_Card;
    QRadioButton *radioButton_Cash;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *verticalLayout_MainDish;
    QLabel *label_MainDish;
    QCheckBox *checkBox_hamburger;
    QCheckBox *checkBox_noodle;
    QCheckBox *checkBox_rice;
    QWidget *verticalLayoutWidget_5;
    QVBoxLayout *verticalLayout_Drink;
    QLabel *label_Drink;
    QCheckBox *checkBox_Cola;
    QCheckBox *checkBox_Sprite;
    QCheckBox *checkBox_BlackTea;
    QPushButton *pushButton_Cancel;
    QLabel *label_total;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_OK;
    QLabel *label_recount;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(801, 443);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label_Title = new QLabel(centralwidget);
        label_Title->setObjectName(QString::fromUtf8("label_Title"));
        label_Title->setGeometry(QRect(300, 60, 191, 41));
        QFont font;
        font.setPointSize(30);
        font.setBold(true);
        label_Title->setFont(font);
        label_Title->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        verticalLayoutWidget_3 = new QWidget(centralwidget);
        verticalLayoutWidget_3->setObjectName(QString::fromUtf8("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(540, 150, 160, 91));
        verticalLayout_Pay = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_Pay->setSpacing(16);
        verticalLayout_Pay->setObjectName(QString::fromUtf8("verticalLayout_Pay"));
        verticalLayout_Pay->setContentsMargins(0, 0, 0, 0);
        label_Pay = new QLabel(verticalLayoutWidget_3);
        label_Pay->setObjectName(QString::fromUtf8("label_Pay"));
        QFont font1;
        font1.setPointSize(17);
        font1.setBold(true);
        font1.setItalic(false);
        font1.setKerning(false);
        label_Pay->setFont(font1);

        verticalLayout_Pay->addWidget(label_Pay);

        radioButton_Card = new QRadioButton(verticalLayoutWidget_3);
        radioButton_Card->setObjectName(QString::fromUtf8("radioButton_Card"));

        verticalLayout_Pay->addWidget(radioButton_Card);

        radioButton_Cash = new QRadioButton(verticalLayoutWidget_3);
        radioButton_Cash->setObjectName(QString::fromUtf8("radioButton_Cash"));

        verticalLayout_Pay->addWidget(radioButton_Cash, 0, Qt::AlignLeft);

        verticalLayoutWidget_4 = new QWidget(centralwidget);
        verticalLayoutWidget_4->setObjectName(QString::fromUtf8("verticalLayoutWidget_4"));
        verticalLayoutWidget_4->setGeometry(QRect(100, 150, 160, 91));
        verticalLayout_MainDish = new QVBoxLayout(verticalLayoutWidget_4);
        verticalLayout_MainDish->setObjectName(QString::fromUtf8("verticalLayout_MainDish"));
        verticalLayout_MainDish->setContentsMargins(0, 0, 0, 0);
        label_MainDish = new QLabel(verticalLayoutWidget_4);
        label_MainDish->setObjectName(QString::fromUtf8("label_MainDish"));
        QFont font2;
        font2.setPointSize(17);
        font2.setBold(true);
        font2.setItalic(false);
        label_MainDish->setFont(font2);

        verticalLayout_MainDish->addWidget(label_MainDish);

        checkBox_hamburger = new QCheckBox(verticalLayoutWidget_4);
        checkBox_hamburger->setObjectName(QString::fromUtf8("checkBox_hamburger"));

        verticalLayout_MainDish->addWidget(checkBox_hamburger);

        checkBox_noodle = new QCheckBox(verticalLayoutWidget_4);
        checkBox_noodle->setObjectName(QString::fromUtf8("checkBox_noodle"));

        verticalLayout_MainDish->addWidget(checkBox_noodle);

        checkBox_rice = new QCheckBox(verticalLayoutWidget_4);
        checkBox_rice->setObjectName(QString::fromUtf8("checkBox_rice"));

        verticalLayout_MainDish->addWidget(checkBox_rice);

        verticalLayoutWidget_5 = new QWidget(centralwidget);
        verticalLayoutWidget_5->setObjectName(QString::fromUtf8("verticalLayoutWidget_5"));
        verticalLayoutWidget_5->setGeometry(QRect(320, 150, 160, 91));
        verticalLayout_Drink = new QVBoxLayout(verticalLayoutWidget_5);
        verticalLayout_Drink->setObjectName(QString::fromUtf8("verticalLayout_Drink"));
        verticalLayout_Drink->setContentsMargins(0, 0, 0, 0);
        label_Drink = new QLabel(verticalLayoutWidget_5);
        label_Drink->setObjectName(QString::fromUtf8("label_Drink"));
        label_Drink->setFont(font2);

        verticalLayout_Drink->addWidget(label_Drink);

        checkBox_Cola = new QCheckBox(verticalLayoutWidget_5);
        checkBox_Cola->setObjectName(QString::fromUtf8("checkBox_Cola"));

        verticalLayout_Drink->addWidget(checkBox_Cola);

        checkBox_Sprite = new QCheckBox(verticalLayoutWidget_5);
        checkBox_Sprite->setObjectName(QString::fromUtf8("checkBox_Sprite"));

        verticalLayout_Drink->addWidget(checkBox_Sprite);

        checkBox_BlackTea = new QCheckBox(verticalLayoutWidget_5);
        checkBox_BlackTea->setObjectName(QString::fromUtf8("checkBox_BlackTea"));

        verticalLayout_Drink->addWidget(checkBox_BlackTea);

        pushButton_Cancel = new QPushButton(centralwidget);
        pushButton_Cancel->setObjectName(QString::fromUtf8("pushButton_Cancel"));
        pushButton_Cancel->setGeometry(QRect(240, 290, 100, 32));
        QFont font3;
        font3.setBold(true);
        pushButton_Cancel->setFont(font3);
        label_total = new QLabel(centralwidget);
        label_total->setObjectName(QString::fromUtf8("label_total"));
        label_total->setGeometry(QRect(270, 340, 251, 31));
        QFont font4;
        font4.setPointSize(18);
        font4.setBold(true);
        label_total->setFont(font4);
        label_total->setAlignment(Qt::AlignCenter);
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(460, 290, 254, 32));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_OK = new QPushButton(widget);
        pushButton_OK->setObjectName(QString::fromUtf8("pushButton_OK"));
        pushButton_OK->setFont(font3);

        horizontalLayout->addWidget(pushButton_OK);

        label_recount = new QLabel(widget);
        label_recount->setObjectName(QString::fromUtf8("label_recount"));
        QFont font5;
        font5.setPointSize(16);
        font5.setBold(true);
        font5.setItalic(true);
        label_recount->setFont(font5);

        horizontalLayout->addWidget(label_recount);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 801, 24));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_Title->setText(QCoreApplication::translate("MainWindow", "\351\273\236\351\244\220\347\263\273\347\265\261", nullptr));
        label_Pay->setText(QCoreApplication::translate("MainWindow", "\344\273\230\346\254\276\346\226\271\345\274\217", nullptr));
        radioButton_Card->setText(QCoreApplication::translate("MainWindow", "\345\210\267\345\215\241 10%off", nullptr));
        radioButton_Cash->setText(QCoreApplication::translate("MainWindow", "\344\273\230\347\217\276 20%off", nullptr));
        label_MainDish->setText(QCoreApplication::translate("MainWindow", "\344\270\273\351\244\220", nullptr));
        checkBox_hamburger->setText(QCoreApplication::translate("MainWindow", "\346\274\242\345\240\241 $10", nullptr));
        checkBox_noodle->setText(QCoreApplication::translate("MainWindow", "\347\231\275\351\272\265\346\242\235 $350", nullptr));
        checkBox_rice->setText(QCoreApplication::translate("MainWindow", "\347\231\275\351\243\257 $350", nullptr));
        label_Drink->setText(QCoreApplication::translate("MainWindow", "\351\243\262\346\226\231", nullptr));
        checkBox_Cola->setText(QCoreApplication::translate("MainWindow", "\345\217\257\346\250\202 $180", nullptr));
        checkBox_Sprite->setText(QCoreApplication::translate("MainWindow", "\351\233\252\347\242\247 $180", nullptr));
        checkBox_BlackTea->setText(QCoreApplication::translate("MainWindow", "\347\264\205\350\214\266 $100", nullptr));
        pushButton_Cancel->setText(QCoreApplication::translate("MainWindow", "Cancel", nullptr));
        label_total->setText(QString());
        pushButton_OK->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        label_recount->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
