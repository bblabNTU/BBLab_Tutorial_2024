import RPi.GPIO as GPIO
import time
import os

# 閮剔蔭雿輻??GPIO 璅∪?
GPIO.setmode(GPIO.BCM)

# 閮剔蔭 GPIO 17 ?箄撓?交芋撘?銝血??典撱箇?銝??駁
GPIO.setup(17, GPIO.IN,pull_up_down=GPIO.PUD_UP )

pin_value = GPIO.input(17)

try:
    while True:
        # 霈??GPIO 17 ????        input_state = GPIO.input(17)
        
        if input_state == GPIO.HIGH:
            
            print("Button not pressed")
        else:
            print("Button pressed")
            os.system("libcamera-still -o /home/user/image.jpg")
        
        time.sleep(0.1)  # ?????辣?脖誑?踹????撓??
except KeyboardInterrupt:
    # 皜? GPIO 閮剔蔭
    GPIO.cleanup()