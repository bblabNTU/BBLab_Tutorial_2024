#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QImage>
#include <QPixmap>
#include <opencv2/opencv.hpp>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_button_open_clicked();
    void on_slider_threshold_valueChanged(int value);
    void on_spinbox_threshold_valueChanged(int value);

private:
    void displayImage(const cv::Mat &image, QLabel *label, bool isGray = false);
    void apply_filters();

    Ui::MainWindow *ui;
    cv::Mat image;
    cv::Mat grayImage;
    cv::Mat binaryImage;
};

#endif // MAINWINDOW_H
