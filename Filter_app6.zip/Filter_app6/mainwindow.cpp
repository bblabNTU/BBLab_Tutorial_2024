#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QPixmap>  // 添加这一行

#include <opencv2/imgproc.hpp>

// Declare filter functions
cv::Mat sepia(const cv::Mat &img);
cv::Mat embossed_edges(const cv::Mat &img);
cv::Mat bw_filter(const cv::Mat &img);

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->slider_threshold, &QSlider::valueChanged, this, &MainWindow::on_slider_threshold_valueChanged);
    connect(ui->spinbox_threshold, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::on_spinbox_threshold_valueChanged);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_button_open_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open Image File"), "", tr("Images (*.png *.xpm *.jpg *.bmp)"));
    if (!fileName.isEmpty()) {
        image = cv::imread(fileName.toStdString());
        cv::cvtColor(image, grayImage, cv::COLOR_BGR2GRAY);
        displayImage(image, ui->label_original);
        displayImage(grayImage, ui->label_gray, true);
        apply_filters();
        on_slider_threshold_valueChanged(ui->slider_threshold->value());
    }
}

void MainWindow::on_slider_threshold_valueChanged(int value)
{
    if (!grayImage.empty()) {
        cv::threshold(grayImage, binaryImage, value, 255, cv::THRESH_BINARY);
        displayImage(binaryImage, ui->label_binary, true);
        ui->spinbox_threshold->setValue(value);
    }
}

void MainWindow::on_spinbox_threshold_valueChanged(int value)
{
    ui->slider_threshold->setValue(value);
}

void MainWindow::displayImage(const cv::Mat &image, QLabel *label, bool isGray)
{
    QImage qimage;
    if (isGray) {
        qimage = QImage(image.data, image.cols, image.rows, image.step, QImage::Format_Grayscale8);
    } else {
        qimage = QImage(image.data, image.cols, image.rows, image.step, QImage::Format_RGB888).rgbSwapped();
    }
    label->setPixmap(QPixmap::fromImage(qimage));  // 使用QPixmap
    label->setScaledContents(true);
}

void MainWindow::apply_filters()
{
    if (!image.empty()) {
        cv::Mat sepia_image = sepia(image);
        cv::Mat embossed_image = embossed_edges(image);
        cv::Mat bw_image = bw_filter(image);

        displayImage(sepia_image, ui->label_sepia);
        displayImage(embossed_image, ui->label_blur);  // Use the same label for Embossed Edges filter
        displayImage(bw_image, ui->label_bw, true);
    }
}

// Define filter functions
cv::Mat sepia(const cv::Mat &img)
{
    cv::Mat img_sepia;
    cv::cvtColor(img, img_sepia, cv::COLOR_BGR2RGB);
    const cv::Mat sepia_kernel = (cv::Mat_<float>(3,3) <<
                                      0.393, 0.769, 0.189,
                                  0.349, 0.686, 0.168,
                                  0.272, 0.534, 0.131);
    cv::transform(img_sepia, img_sepia, sepia_kernel);
    cv::cvtColor(img_sepia, img_sepia, cv::COLOR_RGB2BGR);
    return img_sepia;
}

cv::Mat embossed_edges(const cv::Mat &img)
{
    cv::Mat kernel = (cv::Mat_<float>(3, 3) <<
                          0, -3, -3,
                      3,  0, -3,
                      3,  3,  0);

    cv::Mat img_emboss;
    cv::filter2D(img, img_emboss, CV_32F, kernel);
    cv::convertScaleAbs(img_emboss, img_emboss);

    return img_emboss;
}

cv::Mat bw_filter(const cv::Mat &img)
{
    cv::Mat img_gray;
    cv::cvtColor(img, img_gray, cv::COLOR_BGR2GRAY);
    return img_gray;
}
