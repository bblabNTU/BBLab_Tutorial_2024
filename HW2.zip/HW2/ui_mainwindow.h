/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *formLayoutWidget;
    QGridLayout *gridLayout_2;
    QCheckBox *checkBox;
    QCheckBox *checkBox_4;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_5;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_6;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QLabel *label;
    QFrame *frame;
    QFrame *line;
    QLabel *label_2;
    QLabel *label_3;
    QFrame *line_2;
    QWidget *widget;
    QGridLayout *gridLayout;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(988, 614);
        MainWindow->setInputMethodHints(Qt::ImhFormattedNumbersOnly);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        formLayoutWidget = new QWidget(centralwidget);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(140, 90, 431, 171));
        QFont font;
        font.setFamily(QString::fromUtf8("Courier New"));
        font.setPointSize(20);
        font.setStyleStrategy(QFont::PreferAntialias);
        formLayoutWidget->setFont(font);
        gridLayout_2 = new QGridLayout(formLayoutWidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 6, 4, 6);
        checkBox = new QCheckBox(formLayoutWidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setFont(font);

        gridLayout_2->addWidget(checkBox, 0, 0, 1, 1);

        checkBox_4 = new QCheckBox(formLayoutWidget);
        checkBox_4->setObjectName(QString::fromUtf8("checkBox_4"));
        checkBox_4->setFont(font);

        gridLayout_2->addWidget(checkBox_4, 0, 1, 1, 1);

        checkBox_2 = new QCheckBox(formLayoutWidget);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setFont(font);

        gridLayout_2->addWidget(checkBox_2, 1, 0, 1, 1);

        checkBox_5 = new QCheckBox(formLayoutWidget);
        checkBox_5->setObjectName(QString::fromUtf8("checkBox_5"));
        checkBox_5->setFont(font);

        gridLayout_2->addWidget(checkBox_5, 1, 1, 1, 1);

        checkBox_3 = new QCheckBox(formLayoutWidget);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setFont(font);

        gridLayout_2->addWidget(checkBox_3, 2, 0, 1, 1);

        checkBox_6 = new QCheckBox(formLayoutWidget);
        checkBox_6->setObjectName(QString::fromUtf8("checkBox_6"));
        checkBox_6->setFont(font);

        gridLayout_2->addWidget(checkBox_6, 2, 1, 1, 1);

        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(550, 310, 131, 41));
        pushButton_2->setFont(font);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(720, 310, 131, 41));
        pushButton->setFont(font);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(210, 290, 251, 71));
        label->setFont(font);
        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(110, 30, 461, 241));
        QFont font1;
        font1.setBold(false);
        font1.setStyleStrategy(QFont::PreferAntialias);
        frame->setFont(font1);
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Raised);
        line = new QFrame(frame);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(10, 50, 441, 20));
        line->setFont(font1);
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        label_2 = new QLabel(frame);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 20, 71, 31));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Courier New"));
        font2.setPointSize(20);
        font2.setBold(false);
        font2.setStyleStrategy(QFont::PreferAntialias);
        label_2->setFont(font2);
        label_3 = new QLabel(frame);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(300, 20, 71, 31));
        label_3->setFont(font2);
        line_2 = new QFrame(centralwidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(389, 90, 31, 171));
        QFont font3;
        font3.setStyleStrategy(QFont::PreferAntialias);
        line_2->setFont(font3);
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(630, 90, 221, 171));
        widget->setFont(font3);
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        radioButton = new QRadioButton(widget);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setFont(font);
        radioButton->setInputMethodHints(Qt::ImhNone);
        radioButton->setAutoExclusive(false);

        gridLayout->addWidget(radioButton, 0, 0, 1, 1);

        radioButton_2 = new QRadioButton(widget);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setFont(font);

        gridLayout->addWidget(radioButton_2, 1, 0, 1, 1);

        radioButton->raise();
        radioButton_2->raise();
        MainWindow->setCentralWidget(centralwidget);
        frame->raise();
        formLayoutWidget->raise();
        pushButton_2->raise();
        pushButton->raise();
        label->raise();
        line_2->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 988, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        QWidget::setTabOrder(radioButton, radioButton_2);
        QWidget::setTabOrder(radioButton_2, checkBox);
        QWidget::setTabOrder(checkBox, checkBox_2);
        QWidget::setTabOrder(checkBox_2, checkBox_3);
        QWidget::setTabOrder(checkBox_3, checkBox_4);
        QWidget::setTabOrder(checkBox_4, checkBox_5);
        QWidget::setTabOrder(checkBox_5, checkBox_6);
        QWidget::setTabOrder(checkBox_6, pushButton);
        QWidget::setTabOrder(pushButton, pushButton_2);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        checkBox->setText(QCoreApplication::translate("MainWindow", "\351\235\222\351\206\254\347\276\251\345\244\247\345\210\251\351\272\265 $200", nullptr));
        checkBox_4->setText(QCoreApplication::translate("MainWindow", "\345\217\257\346\250\202 $60", nullptr));
        checkBox_2->setText(QCoreApplication::translate("MainWindow", "\351\256\252\351\255\232\350\233\213\345\240\241 $180", nullptr));
        checkBox_5->setText(QCoreApplication::translate("MainWindow", "\351\233\252\347\242\247 $50", nullptr));
        checkBox_3->setText(QCoreApplication::translate("MainWindow", "\347\217\255\345\260\274\350\277\252\345\205\213\350\233\213 $160", nullptr));
        checkBox_6->setText(QCoreApplication::translate("MainWindow", "\347\264\205\350\214\266 $40", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Cancel", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Total Amount:", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\344\270\273\351\244\220", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\351\243\262\346\226\231", nullptr));
        radioButton->setText(QCoreApplication::translate("MainWindow", "\345\210\267\345\215\241 10%off", nullptr));
        radioButton_2->setText(QCoreApplication::translate("MainWindow", "\347\217\276\351\207\221 $30off", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
